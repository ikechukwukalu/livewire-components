<?php $__env->startSection('content'); ?>
<div class="row justify-content-center m-3">
    <div class="col-md-12">
        <div wire:offline class="alert alert-danger">
            <strong>You are now offline!</strong> Please check your internet connection.
        </div>
    </div>
    <div class="col-md-6">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('get-mails', [
        'email' => $sender,
        'webmails' => [],
        'root' => $folder,
        'cacheTime' => $cache_time,
        'take' => $fetch,
        'commonFolders' => $common_folders
        ])->html();
} elseif ($_instance->childHasBeenRendered('AZh4FDR')) {
    $componentId = $_instance->getRenderedChildComponentId('AZh4FDR');
    $componentTag = $_instance->getRenderedChildComponentTagName('AZh4FDR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AZh4FDR');
} else {
    $response = \Livewire\Livewire::mount('get-mails', [
        'email' => $sender,
        'webmails' => [],
        'root' => $folder,
        'cacheTime' => $cache_time,
        'take' => $fetch,
        'commonFolders' => $common_folders
        ]);
    $html = $response->html();
    $_instance->logRenderedChild('AZh4FDR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    <div class="col-md-6">
        <div class="card m-3 shadow-sm">
            <div class="card-header">
                <h3>Email subject:&nbsp;<span class="text-info" id="email-subject"></span></h3>
            </div>
            <div class="card-body">
                <span class="content-body" style="display: none !important"></span>
                <iframe id="iframe1" style="width: 100%; height: 500px;"></iframe>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\livewire-components\resources\views/get-mails.blade.php ENDPATH**/ ?>