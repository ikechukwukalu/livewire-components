

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Livewire Infinite Scroll')); ?></div>
                <div class="card-body">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('infinite-scroll', [
                        'no_user' => 2,
                        'page' => 1,
                        'message' => "No more users",
                        'fetch' => $fetch,
                        'cache_time' => $cache_time,
                        'users' => $users
                    ])->html();
} elseif ($_instance->childHasBeenRendered('eYqiIwL')) {
    $componentId = $_instance->getRenderedChildComponentId('eYqiIwL');
    $componentTag = $_instance->getRenderedChildComponentTagName('eYqiIwL');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('eYqiIwL');
} else {
    $response = \Livewire\Livewire::mount('infinite-scroll', [
                        'no_user' => 2,
                        'page' => 1,
                        'message' => "No more users",
                        'fetch' => $fetch,
                        'cache_time' => $cache_time,
                        'users' => $users
                    ]);
    $html = $response->html();
    $_instance->logRenderedChild('eYqiIwL', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\livewire-components\resources\views/infinite-scroll.blade.php ENDPATH**/ ?>