<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card" id="table-container">
                <div class="card-header" id="card-header"><?php echo e(__('Livewire Datatable')); ?>

                    <?php if(isset($_GET['page']) && is_int($_GET['page'])): ?>&nbsp;-&nbsp;<b>Page:</b>&nbsp;<?php echo e(number_format($_GET['page'])); ?> <?php endif; ?></div>
                <div class="card-body">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('datatable', [
                        'columns' => $columns,
                        'order_by' => isset($_GET['column']) && isset($_GET['order']) ? [$_GET['column'], $_GET['order'] == 'asc' ? true : false] : $order_by,
                        'page_options' => $page_options,
                        'fetch' => isset($_GET['fetch']) ? $_GET['fetch'] : $fetch,
                        'sort' => $sort,
                        'maxP' => $maxP,
                        'last_page' => 1,
                        'cache_time' => $cache_time
                    ])->html();
} elseif ($_instance->childHasBeenRendered('7jjvysK')) {
    $componentId = $_instance->getRenderedChildComponentId('7jjvysK');
    $componentTag = $_instance->getRenderedChildComponentTagName('7jjvysK');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7jjvysK');
} else {
    $response = \Livewire\Livewire::mount('datatable', [
                        'columns' => $columns,
                        'order_by' => isset($_GET['column']) && isset($_GET['order']) ? [$_GET['column'], $_GET['order'] == 'asc' ? true : false] : $order_by,
                        'page_options' => $page_options,
                        'fetch' => isset($_GET['fetch']) ? $_GET['fetch'] : $fetch,
                        'sort' => $sort,
                        'maxP' => $maxP,
                        'last_page' => 1,
                        'cache_time' => $cache_time
                    ]);
    $html = $response->html();
    $_instance->logRenderedChild('7jjvysK', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\livewire-components\resources\views/datatable.blade.php ENDPATH**/ ?>