<div class="modal fade <?php if($display): ?> show <?php endif; ?>" id="myModal" <?php if($display): ?>
    style="padding-right: 17px; display: block;" <?php endif; ?>>
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">

            <div class="modal-header bg-light">
                <h4 class="modal-title">Edit User - <?php echo e($name); ?></h4>
            </div>

            <div class="modal-body">
                <form wire:submit.prevent='update_user'>
                    <?php echo csrf_field(); ?>
                    <input type="hidden" wire:model="user_id" />
                    <div class="row justify-content-center">
                        <div class="col-md-12">
                            <?php if(session()->has('success')): ?>
                            <div class="alert alert-success alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                                <strong>Success!</strong> <?php echo e(session('success')); ?>

                            </div>
                            <?php endif; ?>
                            <?php if(session()->has('fail')): ?>
                            <div class="alert alert-danger alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                                <strong>Failed!</strong> <?php echo e(session('fail')); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                        <?php $__currentLoopData = $inputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="<?php echo e(ucfirst($input['sort'])); ?>"><?php echo e(ucfirst($input['sort'])); ?>:</label>
                                    <input class="form-control <?php $__errorArgs = [$input['sort']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                        wire:model="<?php echo e($input['sort']); ?>" />
                                    <?php $__errorArgs = [$input['sort']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 mx-auto">
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-block" wire:target="update_user" wire.loading.attr="disabled">
                                    <span wire:loading wire:target="update_user">
                                        <span class="spinner-border spinner-border-sm"></span>&nbsp;Loading...
                                    </span>
                                    <span wire:loading.remove wire:target="update_user">Update</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-danger" wire:click="close_modal" wire:target="close_modal" wire.loading.attr="disabled">
                    <span wire:loading wire:target="close_modal">
                        <span class="spinner-border spinner-border-sm"></span>&nbsp;Removing...
                    </span>
                    <span wire:loading.remove wire:target="close_modal">Close</span>
                </button>
            </div>

        </div>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
    Livewire.on("editUser", (obj) => {
        var modalBackDrop = document.createElement("div");
        modalBackDrop.setAttribute('id', 'modal-backdrop');
        modalBackDrop.setAttribute('class', 'modal-backdrop fade show');

        var modalBackDropLoader = document.createElement("div");
        modalBackDropLoader.setAttribute('id', 'modal-backdrop-loader');
        modalBackDropLoader.setAttribute('class', 'w-100 h-100');

        modalBackDrop.appendChild(modalBackDropLoader);

        window.livewire.find('<?php echo e($_instance->id); ?>').edit_user(obj);
        document.querySelector('body').appendChild(modalBackDrop);
    });
    Livewire.on("closeModal", () => {
        document.getElementById('modal-backdrop').remove();
    });
});
</script><?php /**PATH C:\xampp\htdocs\livewire-components\resources\views/livewire/datatable-modal.blade.php ENDPATH**/ ?>