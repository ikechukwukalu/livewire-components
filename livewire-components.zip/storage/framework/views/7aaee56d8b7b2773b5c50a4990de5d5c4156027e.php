<div>
    <button wire:loading.attr="disabled" wire:target="imap_email_body('<?php echo e($email['uid']); ?>')"
        wire:click="imap_email_body('<?php echo e($email['uid']); ?>')" class="btn btn-primary" type="button"
        wire:offline.attr="disabled">
        <span wire:loading.remove wire:target="imap_email_body('<?php echo e($email['uid']); ?>')">Read</span>
        <span wire:loading wire:target="imap_email_body('<?php echo e($email['uid']); ?>')">Loading...</span>
    </button>
</div><?php /**PATH C:\xampp\htdocs\livewire-components\resources\views/livewire/email-body.blade.php ENDPATH**/ ?>