<?php return array (
  'datatable' => 'App\\Http\\Livewire\\Datatable',
  'datatable-modal' => 'App\\Http\\Livewire\\DatatableModal',
  'email-body' => 'App\\Http\\Livewire\\EmailBody',
  'get-mails' => 'App\\Http\\Livewire\\GetMails',
  'infinite-scroll' => 'App\\Http\\Livewire\\InfiniteScroll',
  'search-email' => 'App\\Http\\Livewire\\SearchEmail',
);